<?php
$conn = mysql_connect('localhost', 'root', '') or die(mysql_error());
$db=mysql_select_db('2my4edge', $conn) or die(mysql_error($conn));
?>