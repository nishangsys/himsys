<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Export the data table</title>
<style type="text/css">
.main { width:350px; font-size:20px; min-height:75px; color:#666; font-family:Tahoma, Geneva, sans-serif; margin:0 auto; margin-top:200px;}
h2 { font-size:15px; font-family:Verdana, Geneva, sans-serif; color:#333; }
a { color:#069; text-decoration:none; }
a:hover { color:#096; text-decoration:underline;}

</style>
</head>

<body>

<div class="main">

<a href="export.php"> Click here to export the database table </a>

</div>


<h2 align="left"> Main tutorial <a href=""> Database table export tutorial </a> </h2>

<h2 align="left"> More tutorial <a href="http://www.2my4edge.com"> www.2my4edge.com </a> </h2>

<h2 align="left"> More demos <a href="http://demos.2my4edge.com"> demos.2my4edge.com </a> </h2> 

</body>
</html>