
bb
 <div class="row">
 
        <div class="col-sm-12">
 <iframe src="tables.PHP" allowFullScreen style="width: 95%;
			float:left;
			background: #FFF;
            border:none;
            height:900px;
            overflow:hidden;
			border-radius: 5px;
		
 "></iframe>
          </div>
          </div>