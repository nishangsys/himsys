<div class="alert alert-success">
  <strong>Message:</strong> Choose a Level
</div>

  <form class="form-horizontal" role="form" action="?next">
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Names:</label>
      <div class="col-sm-10">
       <label for="sel1">Select list (select one):</label>
      <select class="form-control" id="sel1" name="level">
        <option value="200">200</option>
        <option value="300">300</option>
        <option value="400">400</option>
        <option value="500">500</option>
      </select>
      </div>
    </div>
    
   
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-info">Submit</button>
      </div>
    </div>
  </form>
</div>